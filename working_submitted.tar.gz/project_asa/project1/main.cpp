
#include <iostream>

#include "Search.hpp"
#include "Graph.hpp"


void update(int* min, int* max, int id) {
// 	std::cout << "\tmin " << *min << " max " << *max << " id "<< id << std::endl;

	if(*min == -1 || *max == -1)	*min = *max = id;
	else if(id < *min)				*min = id;
	else if(id > *max)				*max = id;
	
// 	std::cout << "\tmin " << *min << " max " << *max << " id "<< id << std::endl << std::endl;
}


 int main () {
	std::cout << std::endl;
	
	int N = 0, E = 0;
	int min = -1, max = -1, crucial = 0;
	
	Graph* g;
	Node* node;
	
	
	std::cin >> N;
	std::cout << "nodes: " << N << std::endl;
	std::cin >> E;
	std::cout << "conections: " << E << std::endl;
	
	g = new Graph(N, E);

	for(int t=0; t<N; t++) {
		node = g->getNodeAt(t);
		node->disable();
		
		if (t>0)
			Search::dfs(g->getNodeAt(0));
		else
			Search::dfs(g->getNodeAt(1));
		
// 		std::cout << g << std::endl;

		if (!g->allVisited()) {
			update(&min, &max, node->getId());
			crucial++;
		}
// 		else std::cout << t << " all visited" << std::endl;
		
		node->enable();
		g->resetVisited();
	}
	

// 	std::cout << g << std::endl;
	
	std::cout << crucial << std::endl;
	std::cout << min << " "<< max << std::endl;	

	delete(g);
	std::cout << std::endl;
	return 0;
}


/*

http://acm.ist.utl.pt/~mooshak/

User: al095
Password: yDDsFk

*/


