 
#include <iostream> 
#include <vector>
#include <stack>


class Node;	// avoid circular dependencies


class Connection {
	Node* _next;
	
	bool _active;
	
	
public:
	
	Connection(Node* next) : _next(next), _active(true) {}
	
	virtual ~Connection() {}
	
	
/*getters*/

	int isActive() const { return _active; }
	
	Node* getNext() const { return _next; }
	
	
/*setters*/

	void enable() { _active = true; }
	void disable() { _active = false; }

};


class Node {
	int _id;
	std::vector<Connection*> _connections;
	bool _active;
	bool _visited;
	
	
public:
	
	Node(int id) : _id(id), _active(true), _visited(false) {}
	
	virtual ~Node() {
		for(unsigned t=0; t<_connections.size(); t++)
			delete(_connections[t]);
	}
	
/*getters*/

	int getId() const { return _id; }
	
	int isActive() const { return _active; }
	
	bool visited() const { return _visited; }

	int getNumberOfConnections() const { return _connections.size(); }
	
	std::vector<Connection*> getConnections() { return _connections; }
	
	Connection* getConnectionAt(int index) const { return _connections[index]; }
	Node* getNodeAt(int index) const { return getConnectionAt(index)->getNext(); }
	
	
/*setters*/

	void enable() { _active = true; }
	void disable() { _active = false; }
	
	void visit() { _visited = true; }
	void resetVisit() { _visited = false; }

	
/*modifiers*/

	void connect(Node* node) {
		_connections.push_back(new Connection(node));
	}
};

class Graph {
	
	std::vector<Node*> _nodes; 
	
public:
	
	Graph(int N, int E) {
		int one=0, two=0, t;
		
		for(t=1; t<=N; t++)
			_nodes.push_back(new Node(t));
		
		for(t=0; t<E; t++) {
			std::cin >> one;
			std::cin >> two;
			
			_nodes[one-1]->connect(_nodes[two-1]);	// vector starts at index 0
			_nodes[two-1]->connect(_nodes[one-1]);	// file starts at 1
		}
	}
	
	Graph(Graph* graph) {
		for(int i=1; i<=graph->getNumberOfNodes(); i++)
			_nodes.push_back(new Node(i));
		
		for(int i=0; i<graph->getNumberOfNodes(); i++)
			for(int j=0; j<graph->getNodeAt(i)->getNumberOfConnections(); j++)
				_nodes[i]->connect(_nodes[graph->getNodeAt(i)->getConnectionAt(j)->getNext()->getId()-1]);
	}
	
	virtual ~Graph() {
		for(unsigned t=0; t<_nodes.size(); t++)
			delete(_nodes[t]);
	}
	
/*getters*/

	int getNumberOfNodes() const { return _nodes.size(); }
	
	Node* getNodeAt(int index) const { return _nodes[index]; }
	
	bool allVisited() {
		for(unsigned t=0; t<_nodes.size(); t++)
			if(_nodes[t]->visited() == false)
				return false;
		return true;
	}
	
	void resetVisited() {
		for(unsigned t=0; t<_nodes.size(); t++)
			_nodes[t]->resetVisit();
	}
};



class Search {
	
public:
	
	Search() {}
	~Search() {}
	
/*algorithms*/
	
	//Iterative DFS
	static void dfs(Node *startNode) {
		std::stack<Node*> stack;
		Node* node;
		std::vector<Connection*> connections;
		
		stack.push(startNode);
		
		while(stack.size() != 0){
			node = stack.top();
			node->visit();
			stack.pop();
			
			connections = node->getConnections();

			for(unsigned t=0; t<connections.size(); t++){
				
				if (!connections[t]->getNext()->visited())
					if(node->isActive())
						stack.push(connections[t]->getNext());
			}
		}
	}
	
};



void update(int* min, int* max, int id) {
	if(*min == -1 || *max == -1)	*min = *max = id;
	else if(id < *min)				*min = id;
	else if(id > *max)				*max = id;
}


 int main () {	
	int N = 0, E = 0;
	int min = -1, max = -1, crucial = 0;
	
	Graph* g;
	Node* node;
	
	
	std::cin >> N;
	std::cin >> E;
	
	g = new Graph(N, E);

	for(int t=0; t<N; t++) {
		node = g->getNodeAt(t);
		node->disable();
		
		if (t>0)
			Search::dfs(g->getNodeAt(0));
		else
			Search::dfs(g->getNodeAt(1));
		
		if (!g->allVisited()) {
			update(&min, &max, node->getId());
			crucial++;
		}
		
		node->enable();
		g->resetVisited();
	}
		

	
	std::cout << crucial << std::endl;
	std::cout << min << " "<< max << std::endl;	

	delete(g);
	return 0;
}



	