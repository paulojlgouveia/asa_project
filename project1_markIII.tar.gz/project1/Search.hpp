#ifndef __SEARCH_H__
#define __SEARCH_H__

#include <iostream>
#include <stack>
#include <list>

#include "Graph.hpp"

class Search {
	
public:
	
	Search() {}
	~Search() {}
	
/*algorithms*/
	
	//Iterative DFS
	static void dfs(Node *startNode) {
		std::stack<Node*> stack;
		std::list<Node*>* adj;
		
		std::list<Node*>::iterator adj_iter;
		Node* node;

		stack.push(startNode);
		
		while(stack.size() != 0){
			node = stack.top();
			node->visit();
			stack.pop();			

			adj = node->getAdjacenciesList();

			for(adj_iter=adj->begin(); adj_iter!=adj->end(); adj_iter++) {
				if (!(*adj_iter)->visited())
						if(node->isActive())
							stack.push(*adj_iter);
			}
		}
	}
	
	/*
		
	static void articulationPoints(Graph* g) {

		int min = -1, max = -1, count = 0;
		int iteration = 1;
		
		int size = g->getNumberOfConnections();
		std::vector<bool, size> visited;
		std::vector<int, size> parent;
		std::vector<int, size> discovery;
		std::vector<int, size> low;
		std::vector<bool, size> ap;

		for (int t=0; t<size; t++) {
			parent[t] = NIL;
			visited[t] = false;
			ap[t] = false;
		}
		
		for (int t=0; t<size; t++) {
			if (visited[t] == false)	
				APVisit(t, visited, discovery, low, parent, ap);
		
		for (int t=1; t<=size; t++) {
			if (ap[t-1] == true) {
				count++;
				
				if(min == -1)		min = max = t;
				else if(t > max)	max = t;
			}
		}
		
		std::cout << count << std::endl;
		std::cout << min << " "<< max << std::endl;	
	}
	
	
	*/
	
	
	
	
	
	
	
	
	/*
	
	static void APVisit(int u, bool visited[], int disc[], int low[], int parent[], bool ap[]) {
		
		static int time = 0;
		int children = 0;
		
		visited[u] = true;
		disc[u] = low[v] = ++time
		
		std::list<int>::iterator i;
		for(i = adj[u].begin(); i != adj[u].end(); ++i) {
			
			int v = *i;
			
			if(!visited[v]) {
				children++;
				parent[v] = u;
				APVisit(v, visited, disc, low, parent, ap);
			
				if (parent[u] == NIL && children > 1)
					ap[u] = true;
				
				if (parent[u] != NIL && low[v] >= disc[u])
					ap[u] = true;
				else if (v != parent[u])
					low[u]  = min(low[u], disc[v]);
				
				
			}
			
			else if (v != parent[u])
				low[u]  = min(low[u], disc[v]);
		
		}
	}
	
	
	static void tarjanVisit(Node* node) {
		
	}
	
	
	static void tarjan(Graph* g) {
		
		int min = -1, max = -1, count = 0;
		
		int size = g->getNumberOfConnections();
		int visited = 0;
		
		std::list<Node*> list;
		std::vector<int, size> discovery;

		
		for (int t=0; t<size; t++) {
			discovery[t] = -1;
		}
		
		
		for (int i=0; i<size; i++) {
			if(discovery[i] == -1) {
				
	
				discovery[i] = low[i] = visited;
				visited++;
				
				list.push_back(g->getNodeAt(i));
				
				Node* next = g->getNodeAt(i);
				
				std::vector<Link*> adj = node->getConnections(); 
				
				for (int j=0; j<adj.size(); j++) {
					if(discovery[adj[j]->getId()-1]|| esta em list) {
					
						
						
						
						
					}
					
				}
				
				
				for(std::vector<Node*>::iterator l_iter = list.begin();
										l_iter != list.end();
											l_iter++) {
					
					if(discovery[l_iter]) {
						
					}
					
				}
				
				
				
				
				
			}
		}

	}

	
	
*/	
};


#endif






